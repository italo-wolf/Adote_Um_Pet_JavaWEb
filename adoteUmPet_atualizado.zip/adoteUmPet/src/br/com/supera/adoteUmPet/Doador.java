package br.com.supera.adoteUmPet;

public class Doador {
	int id;
	String nomeDoador;
	String email;
	String elefone;
	String senha;
	String endereco;
	public Doador() {
		super();
	}
	public Doador(int id, String nomeDoador, String email, String elefone, String senha, String endereco) {
		super();
		this.id = id;
		this.nomeDoador = nomeDoador;
		this.email = email;
		this.elefone = elefone;
		this.senha = senha;
		this.endereco = endereco;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNomeDoador() {
		return nomeDoador;
	}
	public void setNomeDoador(String nomeDoador) {
		this.nomeDoador = nomeDoador;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getElefone() {
		return elefone;
	}
	public void setElefone(String elefone) {
		this.elefone = elefone;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	

}
