package br.com.supera.adoteUmPet.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.conexao.supera.adoteUmPet.cnn;
import br.com.supera.adoteUmPet.Usuario;

public class UsuarioDao {
	
	public void incluir(Usuario usuario) throws ClassNotFoundException, SQLException {
		cnn cnn = new cnn();
		Connection conn = cnn.conectarNoBancoDeDados();
		String sql = "INSERT INTO usuario (nomeUser, email,telefone,senha) VALUES (?, ?, ?, ?)";
		PreparedStatement ps = conn.prepareStatement(sql);
			
		ps.setString(1, usuario.getNomeUser());
		ps.setString(2, usuario.getEmail());
		ps.setString(3, usuario.getTelefone());
		ps.setString(4, usuario.getSenha());
		ps.executeUpdate();
		
		ps.close();
		conn.close();
		
	}
	

}
