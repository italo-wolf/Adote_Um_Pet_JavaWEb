package br.com.supera.adoteUmPet;

public class Animal {

}
