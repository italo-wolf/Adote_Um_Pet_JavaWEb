package br.com.conexao.supera.adoteUmPet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class cnn {

	public Connection conectarNoBancoDeDados() throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		
		Connection conn = null;
			String url = "jdbc:postgresql://localhost/adoteUmPet";
			String usuario = "postgres";
			String senha = "210597";
			
		conn = DriverManager.getConnection(url, usuario, senha);
		return conn;
	}

	public static void main(String[] args) {
	   cnn cnn = new cnn();
		
		try {
			cnn.conectarNoBancoDeDados();
			System.out.println("Conectado");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}
}
